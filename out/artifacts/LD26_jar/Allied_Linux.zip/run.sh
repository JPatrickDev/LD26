#!/bin/sh
java -Djava.library.path="linux/" -jar LD26.jar